# -*- coding: utf-8 -*-

from odoo import models, api, fields

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'
    
    l10n_mx_esignature_ids = fields.Many2many(related='company_id.l10n_mx_esignature_ids', 
        string='MX E-signature', readonly=False)
    last_cfdi_fetch_date = fields.Datetime("Last CFDI fetch date", related="company_id.last_cfdi_fetch_date", readonly=False)
    
    @api.multi
    def import_sat_invoice(self):
        self.company_id.download_cfdi_invoices()
        return True