# -*- coding: utf-8 -*-

from odoo import models, fields

class IrAttachment(models.Model):
    _inherit = 'ir.attachment'
    
    cfdi_uuid = fields.Char("CFDI UUID", copy=False)
    #cfdi_type = fields.Selection([('E','Emisor'),('R','Receptor')],"CFDI Invoice Type", copy=False)
    cfdi_type = fields.Selection([
    ('I', 'Facturas de clientes'), #customer invoice, Emisor.RFC=myself.VAT, Customer invoice
    ('SI', 'Facturas de proveedor'), #Emisor.RFC!=myself.VAT, Supplier bill
    ('E', 'Notas de crédito clientes'), #customer credit note, Emisor.RFC=myself.VAT, Customer credit note
    ('SE', 'Notas de crédito proveedor'), #Emisor.RFC!=myself.VAT, Supplier credit note
    ('P', 'REP de clientes'), #Emisor.RFC=myself.VAT, Customer payment receipt
    ('SP', 'REP de proveedores'), #Emisor.RFC!=myself.VAT, Supplier payment receipt
    ('N', 'Nominas de empleados'), #currently we shall not do anythong with this type of cfdi, Customer Payslip
    ('SN', 'Nómina propia'), #currently we shall not do anythong with this type of cfdi, Supplier Payslip
    ('T', 'Factura de traslado cliente'), #currently we shall not do anythong with this type of cfdi, WayBill Customer
    ('ST', 'Factura de traslado proveedor'),], #currently we shall not do anythong with this type of cfdi, WayBill Supplier                
    "Tipo de comprobante", 
    copy=False)

    date_cfdi = fields.Date('Fecha')
    rfc_tercero = fields.Char("RFC tercero")
    nombre_tercero = fields.Char("Nombre tercero")
    cfdi_total = fields.Float("Importe")
    creado_en_odoo = fields.Boolean("Creado en odoo", copy=False)
