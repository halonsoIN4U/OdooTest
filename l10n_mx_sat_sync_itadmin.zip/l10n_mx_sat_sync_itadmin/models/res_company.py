# -*- coding: utf-8 -*-

from odoo import models, api, fields
from odoo.exceptions import Warning
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, DEFAULT_SERVER_DATE_FORMAT

import base64
import time
import subprocess
import tempfile
import logging

from datetime import datetime
from dateutil.relativedelta import relativedelta
from .portal_sat import PortalSAT

from lxml import etree

_logger = logging.getLogger(__name__)

TRY_COUNT = 3
KEY_TO_PEM_CMD = 'openssl pkcs8 -in %s -inform der -outform pem -out %s -passin file:%s'

def convert_key_cer_to_pem(key, password):
    # TODO compute it from a python way
    with tempfile.NamedTemporaryFile('wb', suffix='.key', prefix='edi.mx.tmp.') as key_file, \
            tempfile.NamedTemporaryFile('wb', suffix='.txt', prefix='edi.mx.tmp.') as pwd_file, \
            tempfile.NamedTemporaryFile('rb', suffix='.key', prefix='edi.mx.tmp.') as keypem_file:
        key_file.write(key)
        key_file.flush()
        pwd_file.write(password)
        pwd_file.flush()
        subprocess.call((KEY_TO_PEM_CMD % (key_file.name, keypem_file.name, pwd_file.name)).split())
        key_pem = keypem_file.read()
    return key_pem

class ResCompany(models.Model):
    _inherit = 'res.company'

    last_cfdi_fetch_date = fields.Datetime("Última sincronización")
    l10n_mx_esignature_ids = fields.Many2many('l10n.mx.esignature.certificate', string='Certificado FIEL')
    
    @api.model
    def auto_import_cfdi_invoices(self):
#         for company in self.search([('l10n_mx_edi_fiel','!=',False),('l10n_mx_edi_fiel_key','!=',False)]):
        for company in self.search([('l10n_mx_esignature_ids','!=',False)]):
            company.download_cfdi_invoices()        
        return True
    
    @api.model
    def import_current_company_invoice(self):
        self.env.user.company_id.sudo().download_cfdi_invoices()
        return True
    
    @api.multi
    def download_cfdi_invoices(self):
        esignature_ids = self.l10n_mx_esignature_ids
        esignature = esignature_ids.sudo().get_valid_certificate()
        if not esignature:
            raise Warning("Archivos incorrectos no son una FIEL.")
            
        if not esignature.content or not esignature.key or not esignature.password:
            raise Warning("Seleccine los archivos FIEL .cer o FIEL .pem.")

        fiel_cert_data = base64.b64decode(esignature.content)
        fiel_pem_data = convert_key_cer_to_pem(base64.decodestring(esignature.key), esignature.password.encode('UTF-8'))

        opt= {'credenciales':None,'rfc':None, 'uuid': None, 'ano': None, 'mes': None, 'dia': 0, 'intervalo_dias':None, 'fecha_inicial': None, 'fecha_final': None, 'tipo':'t', 'tipo_complemento':'-1', 'rfc_emisor': None, 'rfc_receptor': None, 'sin_descargar':False, 'base_datos': False, 'directorio_fiel' : '', 'archivo_uuids' : '', 'estatus':False}
        today = datetime.utcnow()
        if self.last_cfdi_fetch_date:
            last_import_date = self.last_cfdi_fetch_date #datetime.strptime(self.last_cfdi_fetch_date,DEFAULT_SERVER_DATETIME_FORMAT)
            last_import_date - relativedelta(days=2)
            
            fecha_inicial = last_import_date - relativedelta(days=2)
            fecha_final = today + relativedelta(days=2)
            opt['fecha_inicial'] = fecha_inicial
            opt['fecha_final'] = fecha_final
        else:
            ano = today.year
            mes = today.month    
            opt['ano']=ano
            opt['mes']=mes
        
        sat = False
        for i in range(TRY_COUNT):
            sat = PortalSAT(opt['rfc'], 'cfdi-descarga', False)
            if sat.login_fiel(fiel_cert_data, fiel_pem_data):
                time.sleep(1)
                break
        invoice_content_receptor, invoice_content_emisor = {}, {}
        if sat and sat.is_connect:
            invoice_content_receptor, invoice_content_emisor = sat.search(opt)
            sat.logout()
        elif sat:
            sat.logout()
        attachment_obj = self.env['ir.attachment']
        invoice_obj = self.env['account.invoice']
        
        #Supplier
        if invoice_content_receptor:
            uuids = list(invoice_content_receptor.keys())
            attachments = attachment_obj.sudo().search([('cfdi_uuid','in',uuids)])
            exist_uuids = attachments.mapped('cfdi_uuid')
            for uuid,data in invoice_content_receptor.items():
                if uuid in exist_uuids:
                    continue
                values = data[0]
                xml_content = data[1]
                tree = etree.fromstring(xml_content)
                
                xml_content = base64.b64encode(xml_content)
                
                ns_url = tree.nsmap.get('cfdi')
                root_tag = 'Comprobante'
                if ns_url:
                    root_tag = '{'+ns_url+'}Comprobante'
                #Validation to only admit CFDI
                if tree.tag != root_tag:
                    #Invalid invoice file.
                    continue
                
                receptor_elements = tree.xpath('//cfdi:Emisor', namespaces=tree.nsmap)
                r_rfc = receptor_elements[0].get('Rfc')
                r_name = receptor_elements[0].get('Nombre')
                
                cfdi_type = tree.get("TipoDeComprobante",'I')
                if cfdi_type not in ['I','E','P','N','T']:
                    cfdi_type = 'I'
                cfdi_type ='S'+cfdi_type
                
                filename = values.get('receptor','')[:10]+'_'+values.get('rfc_receptor')+'.xml'
                vals = dict(
                        name=filename,
                        datas_fname=filename,
                        type='binary',
                        datas=xml_content,
                        cfdi_uuid=uuid,
                        company_id=self.id,
                        cfdi_type=cfdi_type,
                        rfc_tercero = r_rfc,
                        nombre_tercero = r_name,
                        cfdi_total = values.get('total',0.0),
                    )
                if values.get('date_cfdi'):
                    vals.update({'date_cfdi' : values.get('date_cfdi').strftime(DEFAULT_SERVER_DATE_FORMAT)})
                invoice_exist = invoice_obj.search([('folio_fiscal','=',uuid),('type','=','in_invoice')],limit=1)
                if invoice_exist:
                    vals.update({'creado_en_odoo' : True})

                attachment_obj.create(vals)
        #Customer
        if invoice_content_emisor:
            uuids = list(invoice_content_emisor.keys())
            attachments = attachment_obj.sudo().search([('cfdi_uuid','in',uuids)])
            exist_uuids = attachments.mapped('cfdi_uuid')
            for uuid,data in invoice_content_emisor.items():
                if uuid in exist_uuids:
                    continue
                values = data[0]
                xml_content = data[1]
                tree = etree.fromstring(xml_content)
                
                xml_content = base64.b64encode(xml_content)
                
                ns_url = tree.nsmap.get('cfdi')
                root_tag = 'Comprobante'
                if ns_url:
                    root_tag = '{'+ns_url+'}Comprobante'
                #Validation to only admit CFDI
                if tree.tag != root_tag:
                    #Invalid invoice file.
                    continue
                
                emisor_elements = tree.xpath('//cfdi:Receptor', namespaces=tree.nsmap)
                e_rfc = emisor_elements[0].get('Rfc')
                e_name = emisor_elements[0].get('Nombre')
                
                cfdi_type = tree.get("TipoDeComprobante",'I')
                if cfdi_type not in ['I','E','P','N','T']:
                    cfdi_type = 'I'
                
                filename = values.get('emisor')[:10]+'_'+values.get('rfc_emisor')+'.xml'                
                vals = dict(
                        name=filename,
                        datas_fname=filename,
                        type='binary',
                        datas=xml_content,
                        cfdi_uuid=uuid,
                        cfdi_type=cfdi_type,
                        company_id=self.id,
                        rfc_tercero = e_rfc,
                        nombre_tercero = e_name,
                        cfdi_total = values.get('total',0.0),
                    )
                if values.get('date_cfdi'):
                    vals.update({'date_cfdi' : values.get('date_cfdi').strftime(DEFAULT_SERVER_DATE_FORMAT)})
                invoice_exist = invoice_obj.search([('folio_fiscal','=',uuid),('type','=','out_invoice')],limit=1)
                if invoice_exist:
                    vals.update({'creado_en_odoo' : True})
                    
                attachment_obj.create(vals)
        self.write({'last_cfdi_fetch_date':today.strftime(DEFAULT_SERVER_DATETIME_FORMAT)})
        return
        
