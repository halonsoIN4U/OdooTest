# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
import os
import base64
import json, xmltodict
from odoo.tools.safe_eval import safe_eval

SAT_CLAVE_MAP = {
                'H87': 'Pieza',
                'HUR': 'Hora',
                'KGM': 'Kilogramo',
                'GRM': 'Gramo',
                'LTR': 'Litro',
                'A76': 'Galon',
                'TNE': 'Tonelada',
                'XBX': 'Caja',
                'MTR': 'Metro',
                'LM': 'Metro lineal',
                'MTK': 'M2',
                'MTQ': 'M3',
                'FOT': 'Pie',
                'E48': 'Unidad de servicio',
                'A9': 'Tarifa',
                'DAY': 'Dia',
                'XLT': 'Lote',    
                'SET': 'Conjunto',
                'ACT': 'Actividad',
                'Q3': 'Comida',
                'ROM': 'Habitacion',
                'XPK': 'Paquete',
                'XPX': 'Pallet',    
                'ZZ': 'Mutuamente definido',
                'RK': 'Medida metrica de rollo',
                'C62': 'Uno',    
                'XVN': 'Vehiculo',
                'PR': 'Par',
                'KT': 'Kit',
                'BFT': 'Tableros de pie',
                }

class CfdiInvoiceAttachment(models.TransientModel):
    _name = 'cfdi.invoice.attachment'
    
    @api.model
    def _default_journal(self):
        if self._context.get('default_journal_id', False):
            return self.env['account.journal'].browse(self._context.get('default_journal_id'))
        company_id = self._context.get('company_id', self.env.user.company_id.id)
        domain = [
            ('type', 'in', ['sale']),
            ('company_id', '=', company_id),
        ]
        return self.env['account.journal'].search(domain, limit=1)
    
    @api.model
    def _default_supplier_journal(self):
        if self._context.get('default_journal_id', False):
            return self.env['account.journal'].browse(self._context.get('default_journal_id'))
        company_id = self._context.get('company_id', self.env.user.company_id.id)
        domain = [
            ('type', 'in', ['purchase']),
            ('company_id', '=', company_id),
        ]
        return self.env['account.journal'].search(domain, limit=1)
    
    journal_id = fields.Many2one('account.journal', string='Customer Invoice Journal',
        required=True,
        default=_default_journal,
        domain="[('type', 'in', ['sale'])]")
    
    supplier_journal_id = fields.Many2one('account.journal', string='Supplier Invoice Journal',
        required=True,
        default=_default_supplier_journal,
        domain="[('type', 'in', ['purchase'])]")
    
    credit_journal_id = fields.Many2one('account.journal', string='Customer Credit Journal',
        required=True,
        default=_default_journal,
        domain="[('type', 'in', ['sale'])]")
    
    credit_supplier_journal_id = fields.Many2one('account.journal', string='Supplier Credit Journal',
        required=True,
        default=_default_supplier_journal,
        domain="[('type', 'in', ['purchase'])]")
    
    company_id = fields.Many2one('res.company', string='Company', 
        required=True, readonly=True, 
        default=lambda self: self.env.user.company_id)
    
    @api.multi
    def import_xml_file(self):
        ctx = self._context.copy()
        active_ids = ctx.get('active_ids')
        model = ctx.get('active_model','')
        if model=='ir.attachment' and active_ids:
            attachments = self.env[model].browse(active_ids)
            not_imported_attachment = {}
            imported_attachment = []
            existed_attachment = []
            create_invoice_ids = []
            
            invoice_obj = self.env['account.invoice']
            cfdi_uuids = attachments.mapped("cfdi_uuid")
            exist_invoices = invoice_obj.search([('l10n_mx_edi_cfdi_uuid','in',cfdi_uuids)])
            exist_invoice_uuids = exist_invoices.mapped('l10n_mx_edi_cfdi_uuid')
            
            for attachment in attachments:
                cfdi_uuid = attachment.cfdi_uuid
                if not cfdi_uuid:
                    not_imported_attachment.update({attachment.name:'Not valid Attachment'})
                    continue
                if cfdi_uuid in exist_invoice_uuids:
                    existed_attachment.append(attachment.name)
                    continue
                p, ext = os.path.splitext(attachment.datas_fname)
                if ext[1:].lower() !='xml':
                    not_imported_attachment.update({attachment.name:_("Formato no soportado \"{}\", importa solo archivos XML").format(attachment.datas_fname)})
                    continue
                    
                #file_content = base64.b64decode(attachment.datas)
                try:
                    if attachment.cfdi_type=='I':
                        #record = import_customer_bill_obj.create({'import_file':attachment.datas, 'file_name' : attachment.datas_fname})
                        res = self.import_customer_invoice(attachment.datas,self.journal_id)
                    elif attachment.cfdi_type=='SI':
                        #record = import_vendor_bill_obj.create({'import_file':attachment.datas, 'file_name' : attachment.datas_fname})
                        #res = record.import_xml_file(self.supplier_journal_id)
                        res = self.import_supplier_invoice(attachment.datas,self.supplier_journal_id)
                    elif attachment.cfdi_type=='E':
                        res = self.import_credit_note(attachment.datas,self.credit_journal_id)
                    elif attachment.cfdi_type=='SE':
                        res = self.import_supplier_credit_note(attachment.datas,self.credit_supplier_journal_id)
                        
                    #res = invoice_obj.import_mexico_vendor_bill(file_content, attachment.datas_fname,journal=self.journal_id)
                    if res and type(res)==dict:
                        attachment.write({'creado_en_odoo':True})
                        create_invoice_ids.append(res.get('res_id'))
                        
                except Exception as e:
                    if hasattr(e,'name'):
                        not_imported_attachment.update({attachment:e.name})
                    elif hasattr(e,'message'):
                        not_imported_attachment.update({attachment:e.message})
                    else:
                        not_imported_attachment.update({attachment:str(e)})
                    self.env.cr.rollback()
                    continue
                imported_attachment.append(attachment.name)
            
            ctx = {'create_invoice_ids':create_invoice_ids}
            if existed_attachment:
                ctx.update({'existed_attachment': '<p>'+'<p></p>'.join(existed_attachment)+'</p>'})
            if not_imported_attachment:
                content = ''
                for attachment, error in not_imported_attachment.items():
                    content +='<p>'+ attachment.name + ':</p> <p><strong style="color:red;">&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;bull; Error : </strong> %s </p>'%(error)
                     
                ctx.update({'not_imported_attachment': content}) #'<p>'+'<p></p>'.join(not_imported_attachment)+'</p>'
                
            if imported_attachment:
                ctx.update({'imported_attachment': '<p>'+'<p></p>'.join(imported_attachment)+'</p>' })
            return {
                'name': "Message",
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'import.invoice.process.message',
                'type': 'ir.actions.act_window',
                'target': 'new',
                'context': ctx,
            }
            
        return
    
    @api.model
    def create_update_partner(self,partner_data, is_customer=True,is_supplier=False):
        domain = []
        vendor_name = partner_data.get('@Nombre')
        rfc = partner_data.get('@Rfc')
        partner_obj = self.env['res.partner']
        vals = {}
        if vendor_name:
            domain.append(('name','=',vendor_name))
        if rfc and hasattr(partner_obj, 'rfc'):
            domain.append(('rfc','=',rfc))
            vals.update({'rfc':rfc})
        odoo_vendor = partner_obj.search(domain,limit=1)
        if not odoo_vendor:
            vals.update({'name':vendor_name,'customer':True})
            odoo_vendor = partner_obj.create(vals)
            
        return odoo_vendor
    
    @api.multi
    def import_customer_invoice(self, file_content, journal=False):
        file_coontent = base64.b64decode(file_content)
        file_coontent = file_coontent.replace(b'cfdi:',b'')
        file_coontent = file_coontent.replace(b'tfd:',b'')
        try:
            data = json.dumps(xmltodict.parse(file_coontent)) #,force_list=('Concepto','Traslado',)
            data = json.loads(data)
        except Exception as e:
            data = {}
            raise Warning(str(e))
        invoice_obj = self.env['account.invoice']
        invoice_line_obj = self.env['account.invoice.line']
        product_obj = self.env['product.product']
        product_types = dict(product_obj._fields.get('type')._description_selection(product_obj.env))
        
        tax_obj = self.env['account.tax']
        partner_data = data.get('Comprobante',{}).get('Receptor',{})
        invoice_line_data = data.get('Comprobante',{}).get('Conceptos',{}).get('Concepto',[])
        if type(invoice_line_data)!=list:
            invoice_line_data = [invoice_line_data]
            
        date_invoice = data.get('Comprobante',{}).get('@Fecha')
        customer_reference = data.get('Comprobante',{}).get('@Serie','') + data.get('Comprobante',{}).get('@Folio','')
        receptor_data = data.get('Comprobante',{}).get('Receptor',{})
        timbrado_data = data.get('Comprobante',{}).get('Complemento',{}).get('TimbreFiscalDigital',{})

        if customer_reference != '':
            invoice_exist = invoice_obj.search([('reference','=',customer_reference)],limit=1)
            if invoice_exist:
                raise Warning("Factura ya existende con la referencia del vendedor %s"%(customer_reference))

        ctx = self._context.copy()
        ctx.update({'default_type': 'out_invoice', 'type': 'out_invoice', 'journal_type': 'sale'})
        
        partner = self.create_update_partner(partner_data)
        if not journal:
            journal = invoice_obj.with_context(ctx)._default_journal()
        #journal = invoice_obj.with_context(ctx)._default_journal()

        invoice_vals = {
            'type':'out_invoice',
            'journal_type':'sale',
            'partner_id':partner.id,
            'reference':customer_reference,
            'folio_fiscal':timbrado_data.get('@UUID'),
            'forma_pago':data.get('Comprobante',{}).get('@FormaPago',{}), 
            'methodo_pago':data.get('Comprobante',{}).get('@MetodoPago',{}),
            'uso_cfdi':receptor_data.get('@UsoCFDI'),

            'tipo_comprobante': data.get('Comprobante',{}).get('@TipoDeComprobante'),
            'estado_factura': 'factura_correcta', 
            'tipocambio': data.get('Comprobante',{}).get('@TipoCambio'),
            #'currency_id.name': data.get('Comprobante',{}).get('@Moneda'),    
            
            'numero_cetificado': timbrado_data.get('@NoCertificadoSAT'),
            'fecha_certificacion': data.get('Comprobante',{}).get('@FechaTimbrado'),
            'selo_digital_cdfi': timbrado_data.get('@SelloCFD'),
            'selo_sat': timbrado_data.get('@SelloSAT'),
            'currency_id' : journal.currency_id.id or journal.company_id.currency_id.id or self.env.user.company_id.currency_id.id,
            'company_id' : self.env.user.company_id.id,
            'journal_id' : journal.id,
            }
        
        currency_code = data.get('Comprobante',{}).get('@Moneda','MXN')
        currency = self.env['res.currency'].search([('name','=',currency_code)], limit=1)
        if not currency:
            currency = self.env['res.currency'].with_context(active_test=False).search([('name','=',currency_code)], limit=1)
            if currency:
                currency.write({'active':True})
        if currency:
            invoice_vals.update({'currency_id':currency.id})
        
        customer_invoice = invoice_obj.with_context(ctx).new(invoice_vals)
        customer_invoice._onchange_partner_id()
        invoice_vals = customer_invoice._convert_to_write({name: customer_invoice[name] for name in customer_invoice._cache})
        invoice_vals.update({'date_invoice':date_invoice,'journal_id' : journal.id,})
        invoice_exist = invoice_obj.with_context(ctx).create(invoice_vals)
        fields = invoice_line_obj._fields.keys()
        ctx.update({'journal':invoice_exist.journal_id.id})
        
        search_code = 'Propio' #self.search_code or 
        p_supplierinfo = self.env['product.supplierinfo']
        
        for line in invoice_line_data:
            product_name = line.get('@Descripcion')
            discount_amount = safe_eval(line.get('@Descuento','0.0'))
            unit_price = safe_eval(line.get('@ValorUnitario','0.0'))
            default_code = line.get('@NoIdentificacion')
            qty = safe_eval(line.get('@Cantidad','1.0'))
            clave_unidad = line.get('@ClaveUnidad')
            clave_producto = safe_eval(line.get('@ClaveProdServ'))
            taxes = line.get('Impuestos',{}).get('Traslados',{}).get('Traslado')
            if taxes:
                if type(taxes)!=list:
                    taxes = [taxes]
                tax_ids = []
                if taxes:
                    for tax in taxes:
                        tax_exist = tax_obj.search([('impuesto','=',tax.get('@Impuesto')),('type_tax_use','=','sale')],limit=1)
                        if not tax_exist:
                            raise Warning("La factura contiene impuestos que no han sido configurados. Por favor configure los impuestos primero")
                        tax_ids.append(tax_exist.id)
                       
            product_exist = False
            if default_code:
                if search_code=='Propio':
                    product_exist = product_obj.search([('default_code','=',default_code)],limit=1)
                else:
                    supplierinfo_exist = p_supplierinfo.search([('product_code','=',default_code)],limit=1)
                    if supplierinfo_exist.product_tmpl_id:
                        product_exist = supplierinfo_exist.product_tmpl_id.product_variant_id
            if not product_exist:
                product_exist = product_obj.search([('name','=',product_name)],limit=1)
                
            if not product_exist:
                um_descripcion = SAT_CLAVE_MAP[clave_unidad]
                if 'product' in product_types:
                    product_exist = product_obj.create({'default_code':default_code, 'name':product_name, 'standard_price' : unit_price, 'type' : 'product', 'unidad_medida' : um_descripcion, 'clave_producto' : clave_producto,})
                else:
                    product_exist = product_obj.create({'default_code':default_code, 'name':product_name, 'standard_price' : unit_price, 'unidad_medida' : um_descripcion, 'clave_producto' : clave_producto,})
            if discount_amount:
                discount_percent = discount_amount*100.0/(unit_price*qty)
            else:
                discount_percent=0.0
            
            line_data = invoice_line_obj.default_get(fields)    
            line_data.update({
                            'invoice_id': invoice_exist.id,
                            'product_id':product_exist.id,
                            'name': product_name,
                            'uom_id': product_exist.uom_po_id.id,
                            'price_unit': unit_price,
                            'discount':discount_percent,
                        })
            
            invoice_line = invoice_line_obj.with_context(ctx).new(line_data)
            invoice_line.with_context(ctx)._onchange_product_id()
            line_data = invoice_line._convert_to_write({name: invoice_line[name] for name in invoice_line._cache})
            if taxes:
                line_data.update({
                  'invoice_line_tax_ids':[(6,0,tax_ids)],
                  'quantity': qty or 1,
                  'price_unit': unit_price,
                  })
            else:
                line_data.update({
                  'invoice_line_tax_ids':[],
                  'quantity': qty or 1,
                  'price_unit': unit_price,
                  })
            invoice_line_obj.create(line_data)
        invoice_exist.compute_taxes()
        action = self.env.ref('account.action_invoice_tree1')
        result = action.read()[0]
        res = self.env.ref('account.invoice_form', False)
        result['views'] = [(res and res.id or False, 'form')]
        result['res_id'] = invoice_exist.id
        return result
    
    @api.multi
    def import_supplier_invoice(self, file_content, journal=False):
        file_content = base64.b64decode(file_content)
        file_content = file_content.replace(b'cfdi:',b'')
        file_content = file_content.replace(b'tfd:',b'')
        try:
            data = json.dumps(xmltodict.parse(file_content)) #,force_list=('Concepto','Traslado',)
            data = json.loads(data)
        except Exception as e:
            data = {}
            raise Warning(str(e))
        invoice_obj = self.env['account.invoice']
        invoice_line_obj = self.env['account.invoice.line']
        product_obj = self.env['product.product']
        product_types = dict(product_obj._fields.get('type')._description_selection(product_obj.env))
        
        tax_obj = self.env['account.tax']
        vendor_data = data.get('Comprobante',{}).get('Emisor',{})
        invoice_line_data = data.get('Comprobante',{}).get('Conceptos',{}).get('Concepto',[])
        if type(invoice_line_data)!=list:
            invoice_line_data = [invoice_line_data]
            
        date_invoice = data.get('Comprobante',{}).get('@Fecha')
        vendor_reference = data.get('Comprobante',{}).get('@Serie','') + data.get('Comprobante',{}).get('@Folio','')
        receptor_data = data.get('Comprobante',{}).get('Receptor',{})
        timbrado_data = data.get('Comprobante',{}).get('Complemento',{}).get('TimbreFiscalDigital',{})

        if vendor_reference != '':
            invoice_exist = invoice_obj.search([('reference','=',vendor_reference)],limit=1)
            if invoice_exist:
                raise Warning("Factura ya existende con la referencia del vendedor %s"%(vendor_reference))
        
        vendor = self.create_update_partner(vendor_data, is_supplier=True)
        
        ctx = self._context.copy()
        ctx.update({'default_type': 'in_invoice', 'type': 'in_invoice', 'journal_type': 'purchase'})
        if not journal:
            journal = invoice_obj.with_context(ctx)._default_journal()
            
        invoice_vals = {
            'type':'in_invoice',
            'journal_type':'purchase',
            'partner_id':vendor.id,
            'reference':vendor_reference,
            'folio_fiscal':timbrado_data.get('@UUID'),
            'forma_pago':data.get('Comprobante',{}).get('@FormaPago',{}), 
            'methodo_pago':data.get('Comprobante',{}).get('@MetodoPago',{}),
            'uso_cfdi':receptor_data.get('@UsoCFDI'),

            'tipo_comprobante': data.get('Comprobante',{}).get('@TipoDeComprobante'),
            'estado_factura': 'factura_correcta', 
            'tipocambio': data.get('Comprobante',{}).get('@TipoCambio'),
            #'currency_id.name': data.get('Comprobante',{}).get('@Moneda'),    
            
            'numero_cetificado': timbrado_data.get('@NoCertificadoSAT'),
            'fecha_certificacion': data.get('Comprobante',{}).get('@FechaTimbrado'),
            'selo_digital_cdfi': timbrado_data.get('@SelloCFD'),
            'selo_sat': timbrado_data.get('@SelloSAT'),
            'currency_id' : journal.currency_id.id or journal.company_id.currency_id.id or self.env.user.company_id.currency_id.id,
            'company_id' : self.env.user.company_id.id,
            'journal_id' : journal.id,
            }
        
        currency_code = data.get('Comprobante',{}).get('@Moneda','MXN')
        currency = self.env['res.currency'].search([('name','=',currency_code)], limit=1)
        if not currency:
            currency = self.env['res.currency'].with_context(active_test=False).search([('name','=',currency_code)], limit=1)
            if currency:
                currency.write({'active':True})
        if currency:
            invoice_vals.update({'currency_id':currency.id})
            
        vendor_invoice = invoice_obj.with_context(ctx).new(invoice_vals)
        vendor_invoice._onchange_partner_id()
        invoice_vals = vendor_invoice._convert_to_write({name: vendor_invoice[name] for name in vendor_invoice._cache})
        invoice_vals.update({'date_invoice':date_invoice,'journal_id' : journal.id,})
        invoice_exist = invoice_obj.with_context(ctx).create(invoice_vals)
        fields = invoice_line_obj._fields.keys()
        ctx.update({'journal':invoice_exist.journal_id.id})
        
        #search_code = self.search_code or 'Propio'
        search_code = 'Propio' #self.search_code or 
        p_supplierinfo = self.env['product.supplierinfo']
        
        for line in invoice_line_data:
            product_name = line.get('@Descripcion')
            discount_amount = safe_eval(line.get('@Descuento','0.0'))
            unit_price = safe_eval(line.get('@ValorUnitario','0.0'))
            default_code = line.get('@NoIdentificacion')
            qty = safe_eval(line.get('@Cantidad','1.0'))
            clave_unidad = line.get('@ClaveUnidad')
            clave_producto = safe_eval(line.get('@ClaveProdServ'))
            taxes = line.get('Impuestos',{}).get('Traslados',{}).get('Traslado')
            if taxes:
                if type(taxes)!=list:
                    taxes = [taxes]
                tax_ids = []
                if taxes:
                    for tax in taxes:
                        tax_exist = tax_obj.search([('impuesto','=',tax.get('@Impuesto')),('type_tax_use','=','purchase')],limit=1)
                        if not tax_exist:
                            raise Warning("La factura contiene impuestos que no han sido configurados. Por favor configure los impuestos primero")
                        tax_ids.append(tax_exist.id)
            
            product_exist = False
            if default_code:
                if search_code=='Propio':
                    product_exist = product_obj.search([('default_code','=',default_code)],limit=1)
                else:
                    supplierinfo_exist = p_supplierinfo.search([('product_code','=',default_code)],limit=1)
                    if supplierinfo_exist.product_tmpl_id:
                        product_exist = supplierinfo_exist.product_tmpl_id.product_variant_id
            if not product_exist:
                product_exist = product_obj.search([('name','=',product_name)],limit=1)
                
            if not product_exist:
                um_descripcion = SAT_CLAVE_MAP[clave_unidad]
                if 'product' in product_types:
                    product_exist = product_obj.create({'default_code':default_code, 'name':product_name, 'standard_price' : unit_price, 'type' : 'product', 'unidad_medida' : um_descripcion, 'clave_producto' : clave_producto,})
                else:
                    product_exist = product_obj.create({'default_code':default_code, 'name':product_name, 'standard_price' : unit_price, 'unidad_medida' : um_descripcion, 'clave_producto' : clave_producto,})
                    
            if discount_amount:
                discount_percent = discount_amount*100.0/(unit_price*qty)
            else:
                discount_percent=0.0
            
            line_data = invoice_line_obj.default_get(fields)    
            line_data.update({
                            'invoice_id': invoice_exist.id,
                            'product_id':product_exist.id,
                            'name': product_name,
                            'uom_id': product_exist.uom_po_id.id,
                            'price_unit': unit_price,
                            'discount':discount_percent,
                        })
            
            invoice_line = invoice_line_obj.with_context(ctx).new(line_data)
            invoice_line.with_context(ctx)._onchange_product_id()
            line_data = invoice_line._convert_to_write({name: invoice_line[name] for name in invoice_line._cache})
            if taxes:
                line_data.update({
                  'invoice_line_tax_ids':[(6,0,tax_ids)],
                  'quantity': qty or 1,
                  'price_unit': unit_price,
                  })
            else:
                line_data.update({
                  'invoice_line_tax_ids':[],
                  'quantity': qty or 1,
                  'price_unit': unit_price,
                  })
            invoice_line_obj.create(line_data)
        invoice_exist.compute_taxes()
        action = self.env.ref('account.action_invoice_tree2')
        result = action.read()[0]
        res = self.env.ref('account.invoice_supplier_form', False)
        result['views'] = [(res and res.id or False, 'form')]
        result['res_id'] = invoice_exist.id
        return result
    
    @api.model
    def import_credit_note(self, file_content, journal=False):
        file_content = base64.b64decode(file_content)
        file_content = file_content.replace(b'cfdi:',b'')
        file_content = file_content.replace(b'tfd:',b'')
        try:
            data = json.dumps(xmltodict.parse(file_content)) #,force_list=('Concepto','Traslado',)
            data = json.loads(data)
        except Exception as e:
            data = {}
            raise Warning(str(e))
        invoice_obj = self.env['account.invoice']
        invoice_line_obj = self.env['account.invoice.line']
        product_obj = self.env['product.product']
        product_types = dict(product_obj._fields.get('type')._description_selection(product_obj.env))
        
        tax_obj = self.env['account.tax']
        partner_data = data.get('Comprobante',{}).get('Emisor',{})
        invoice_line_data = data.get('Comprobante',{}).get('Conceptos',{}).get('Concepto',[])
        if type(invoice_line_data)!=list:
            invoice_line_data = [invoice_line_data]
            
        date_invoice = data.get('Comprobante',{}).get('@Fecha')
        customer_reference = data.get('Comprobante',{}).get('@Serie','') + data.get('Comprobante',{}).get('@Folio','')
        receptor_data = data.get('Comprobante',{}).get('Receptor',{})
        timbrado_data = data.get('Comprobante',{}).get('Complemento',{}).get('TimbreFiscalDigital',{})

        if customer_reference != '':
            invoice_exist = invoice_obj.search([('reference','=',customer_reference)],limit=1)
            if invoice_exist:
                raise Warning("Factura ya existende con la referencia del vendedor %s"%(customer_reference))

        ctx = self._context.copy()
        ctx.update({'default_type': 'out_refund', 'type': 'out_refund', 'journal_type': 'sale'})

        partner = self.create_update_partner(partner_data)
        if not journal:
            journal = invoice_obj.with_context(ctx)._default_journal()
        #journal = invoice_obj.with_context(ctx)._default_journal()

        invoice_vals = {
            'type':'out_refund',
            'journal_type':'sale',
            'partner_id':partner.id,
            'reference':customer_reference,
            'folio_fiscal':timbrado_data.get('@UUID'),
            'forma_pago':data.get('Comprobante',{}).get('@FormaPago',{}), 
            'methodo_pago':data.get('Comprobante',{}).get('@MetodoPago',{}),
            'uso_cfdi':receptor_data.get('@UsoCFDI'),

            'tipo_comprobante': data.get('Comprobante',{}).get('@TipoDeComprobante'),
            'estado_factura': 'factura_correcta', 
            'tipocambio': data.get('Comprobante',{}).get('@TipoCambio'),
            
            'numero_cetificado': timbrado_data.get('@NoCertificadoSAT'),
            'fecha_certificacion': data.get('Comprobante',{}).get('@FechaTimbrado'),
            'selo_digital_cdfi': timbrado_data.get('@SelloCFD'),
            'selo_sat': timbrado_data.get('@SelloSAT'),
            'currency_id' : journal.currency_id.id or journal.company_id.currency_id.id or self.env.user.company_id.currency_id.id,
            'company_id' : self.env.user.company_id.id,
            'journal_id' : journal.id,
            }
        
        currency_code = data.get('Comprobante',{}).get('@Moneda','MXN')
        currency = self.env['res.currency'].search([('name','=',currency_code)], limit=1)
        if not currency:
            currency = self.env['res.currency'].with_context(active_test=False).search([('name','=',currency_code)], limit=1)
            if currency:
                currency.write({'active':True})
        if currency:
            invoice_vals.update({'currency_id':currency.id})
                    
        
        customer_invoice = invoice_obj.with_context(ctx).new(invoice_vals)
        customer_invoice._onchange_partner_id()
        invoice_vals = customer_invoice._convert_to_write({name: customer_invoice[name] for name in customer_invoice._cache})
        invoice_vals.update({'date_invoice':date_invoice,'journal_id' : journal.id,})
        invoice_exist = invoice_obj.with_context(ctx).create(invoice_vals)
        fields = invoice_line_obj._fields.keys()
        ctx.update({'journal':invoice_exist.journal_id.id})
        
        search_code = self.search_code or 'Propio'
        p_supplierinfo = self.env['product.supplierinfo']
        
        for line in invoice_line_data:
            product_name = line.get('@Descripcion')
            discount_amount = safe_eval(line.get('@Descuento','0.0'))
            unit_price = safe_eval(line.get('@ValorUnitario','0.0'))
            default_code = line.get('@NoIdentificacion')
            qty = safe_eval(line.get('@Cantidad','1.0'))
            clave_unidad = line.get('@ClaveUnidad')
            clave_producto = safe_eval(line.get('@ClaveProdServ'))
            taxes = line.get('Impuestos',{}).get('Traslados',{}).get('Traslado')
            if taxes:
                if type(taxes)!=list:
                    taxes = [taxes]
                tax_ids = []
                if taxes:
                    for tax in taxes:
                        tax_exist = tax_obj.search([('impuesto','=',tax.get('@Impuesto')),('type_tax_use','=','sale')],limit=1)
                        if not tax_exist:
                            raise Warning("La factura contiene impuestos que no han sido configurados. Por favor configure los impuestos primero")
                        tax_ids.append(tax_exist.id)
                       
            product_exist = False
            if default_code:
                if search_code=='Propio':
                    product_exist = product_obj.search([('default_code','=',default_code)],limit=1)
                else:
                    supplierinfo_exist = p_supplierinfo.search([('product_code','=',default_code)],limit=1)
                    if supplierinfo_exist.product_tmpl_id:
                        product_exist = supplierinfo_exist.product_tmpl_id.product_variant_id
            if not product_exist:
                product_exist = product_obj.search([('name','=',product_name)],limit=1)
                
            if not product_exist:
                um_descripcion = SAT_CLAVE_MAP[clave_unidad]
                if 'product' in product_types:
                    product_exist = product_obj.create({'default_code':default_code, 'name':product_name, 'standard_price' : unit_price, 'type' : 'product', 'unidad_medida' : um_descripcion, 'clave_producto' : clave_producto,})
                else:
                    product_exist = product_obj.create({'default_code':default_code, 'name':product_name, 'standard_price' : unit_price, 'unidad_medida' : um_descripcion, 'clave_producto' : clave_producto,})
                    
            if discount_amount:
                discount_percent = discount_amount*100.0/(unit_price*qty)
            else:
                discount_percent=0.0
            
            line_data = invoice_line_obj.default_get(fields)    
            line_data.update({
                            'invoice_id': invoice_exist.id,
                            'product_id':product_exist.id,
                            'name': product_name,
                            'uom_id': product_exist.uom_po_id.id,
                            'price_unit': unit_price,
                            'discount':discount_percent,
                        })
            
            invoice_line = invoice_line_obj.with_context(ctx).new(line_data)
            invoice_line.with_context(ctx)._onchange_product_id()
            line_data = invoice_line._convert_to_write({name: invoice_line[name] for name in invoice_line._cache})
            if taxes:
                line_data.update({
                  'invoice_line_tax_ids':[(6,0,tax_ids)],
                  'quantity': qty or 1,
                  'price_unit': unit_price,
                  })
            else:
                line_data.update({
                  'invoice_line_tax_ids':[],
                  'quantity': qty or 1,
                  'price_unit': unit_price,
                  })
            invoice_line_obj.create(line_data)
        invoice_exist.compute_taxes()
        action = self.env.ref('account.action_invoice_tree1')
        result = action.read()[0]
        res = self.env.ref('account.invoice_form', False)
        result['views'] = [(res and res.id or False, 'form')]
        result['res_id'] = invoice_exist.id
        return result
    
    @api.model
    def import_supplier_credit_note(self, file_content, journal=False):
        file_content = base64.b64decode(file_content)
        file_content = file_content.replace(b'cfdi:',b'')
        file_content = file_content.replace(b'tfd:',b'')
        try:
            data = json.dumps(xmltodict.parse(file_content))
            data = json.loads(data)
        except Exception as e:
            data = {}
            raise Warning(str(e))
        invoice_obj = self.env['account.invoice']
        invoice_line_obj = self.env['account.invoice.line']
        product_obj = self.env['product.product']
        tax_obj = self.env['account.tax']
        product_types = dict(product_obj._fields.get('type')._description_selection(product_obj.env))
        
        vendor_data = data.get('Comprobante',{}).get('Emisor',{})
        invoice_line_data = data.get('Comprobante',{}).get('Conceptos',{}).get('Concepto',[])
        if type(invoice_line_data)!=list:
            invoice_line_data = [invoice_line_data]
            
        date_invoice = data.get('Comprobante',{}).get('@Fecha')
        vendor_reference = data.get('Comprobante',{}).get('@Serie','') + data.get('Comprobante',{}).get('@Folio','')
        receptor_data = data.get('Comprobante',{}).get('Receptor',{})
        timbrado_data = data.get('Comprobante',{}).get('Complemento',{}).get('TimbreFiscalDigital',{})

        if vendor_reference != '':
            invoice_exist = invoice_obj.search([('reference','=',vendor_reference)],limit=1)
            if invoice_exist:
                raise Warning("Factura ya existende con la referencia del vendedor %s"%(vendor_reference))
        
        vendor = self.env['import.purchase.order.from.xml'].create_update_vendor(vendor_data)
        
        ctx = self._context.copy()
        ctx.update({'default_type': 'in_refund', 'type': 'in_refund', 'journal_type': 'purchase'})
        
        invoice_fields = invoice_obj._fields.keys()
        invoice_vals = invoice_obj.default_get(invoice_fields)
        if not journal:
            journal = invoice_obj.with_context(ctx)._default_journal()
        #journal = invoice_obj.with_context(ctx)._default_journal()
        
        invoice_vals.update({
            'type':'in_refund',
            'journal_type':'purchase',
            'partner_id':vendor.id,
            'reference':vendor_reference,
            'folio_fiscal':timbrado_data.get('@UUID'),
            'forma_pago':data.get('Comprobante',{}).get('@FormaPago',{}), 
            'methodo_pago':data.get('Comprobante',{}).get('@MetodoPago',{}),
            'uso_cfdi':receptor_data.get('@UsoCFDI'),

            'tipo_comprobante': data.get('Comprobante',{}).get('@TipoDeComprobante'),
            'estado_factura': 'factura_correcta', 
            'tipocambio': data.get('Comprobante',{}).get('@TipoCambio'),
            #'currency_id.name': data.get('Comprobante',{}).get('@Moneda'),    
            
            'numero_cetificado': timbrado_data.get('@NoCertificadoSAT'),
            'fecha_certificacion': data.get('Comprobante',{}).get('@FechaTimbrado'),
            'selo_digital_cdfi': timbrado_data.get('@SelloCFD'),
            'selo_sat': timbrado_data.get('@SelloSAT'),
            'currency_id' : journal.currency_id.id or journal.company_id.currency_id.id or self.env.user.company_id.currency_id.id,
            'company_id' : self.env.user.company_id.id,
            'journal_id' : journal.id,
            })
        
        currency_code = data.get('Comprobante',{}).get('@Moneda','MXN')
        currency = self.env['res.currency'].search([('name','=',currency_code)], limit=1)
        if not currency:
            currency = self.env['res.currency'].with_context(active_test=False).search([('name','=',currency_code)], limit=1)
            if currency:
                currency.write({'active':True})
        if currency:
            invoice_vals.update({'currency_id':currency.id})
            
        vendor_invoice = invoice_obj.with_context(ctx).new(invoice_vals)
        vendor_invoice._onchange_partner_id()
        invoice_vals = vendor_invoice._convert_to_write({name: vendor_invoice[name] for name in vendor_invoice._cache})
        invoice_vals.update({'date_invoice':date_invoice,'journal_id' : journal.id,})
        invoice_exist = invoice_obj.with_context(ctx).create(invoice_vals)
        fields = invoice_line_obj._fields.keys()
        ctx.update({'journal':invoice_exist.journal_id.id})
        for line in invoice_line_data:
            product_name = line.get('@Descripcion')
            discount_amount = safe_eval(line.get('@Descuento','0.0'))
            unit_price = safe_eval(line.get('@ValorUnitario','0.0'))
            default_code = line.get('@NoIdentificacion')
            qty = safe_eval(line.get('@Cantidad','1.0'))
            clave_unidad = line.get('@ClaveUnidad')
            clave_producto = safe_eval(line.get('@ClaveProdServ'))
            taxes = line.get('Impuestos',{}).get('Traslados',{}).get('Traslado')
            if type(taxes)!=list:
                taxes = [taxes]
            tax_ids = []
            if taxes:
                for tax in taxes:
                    tax_exist = tax_obj.search([('impuesto','=',tax.get('@Impuesto')),('type_tax_use','=','purchase')],limit=1)
                    if not tax_exist:
                        raise Warning("La factura contiene impuestos que no han sido configurados. Por favor configure los impuestos primero")
                    tax_ids.append(tax_exist.id)
            if default_code:
                product_exist = product_obj.search([('default_code','=',default_code)],limit=1)
            else:
                product_exist = product_obj.search([('name','=',product_name)],limit=1)
            if not product_exist:
                if 'product' in product_types:
                    product_exist = product_obj.create({'default_code':default_code, 'name':product_name, 'lst_price' : unit_price, 'type' : 'product', 'clave_unidad' : clave_unidad, 'clave_producto' : clave_producto,})
                else:
                    product_exist = product_obj.create({'default_code':default_code, 'name':product_name, 'lst_price' : unit_price, 'clave_unidad' : clave_unidad, 'clave_producto' : clave_producto,})
            if discount_amount:
                discount_percent = discount_amount*100.0/(unit_price*qty)
            else:
                discount_percent=0.0
            
            line_data = invoice_line_obj.default_get(fields)    
            line_data.update({
                            'invoice_id': invoice_exist.id,
                            'product_id':product_exist.id,
                            'name': product_name,
                            'uom_id': product_exist.uom_po_id.id,
                            'price_unit': unit_price,
                            'discount':discount_percent,
                        })
            
            invoice_line = invoice_line_obj.with_context(ctx).new(line_data)
            invoice_line.with_context(ctx)._onchange_product_id()
            line_data = invoice_line._convert_to_write({name: invoice_line[name] for name in invoice_line._cache})
            line_data.update({
                'invoice_line_tax_ids':[(6,0,tax_ids)],
                'quantity': qty or 1,
                'price_unit': unit_price,
                })
            invoice_line_obj.create(line_data)
        invoice_exist.compute_taxes()
        action = self.env.ref('account.action_invoice_tree2')
        result = action.read()[0]
        res = self.env.ref('account.invoice_supplier_form', False)
        result['views'] = [(res and res.id or False, 'form')]
        result['res_id'] = invoice_exist.id
        return result