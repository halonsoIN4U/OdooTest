odoo.define('l10n_mx_sat_sync_itadmin.ListController', function (require) {
"use strict";

var ListController = require('web.ListController');

ListController.include({
	renderButtons: function ($node) {
		this._super($node)
		if (this.modelName==='ir.attachment' && !this.noLeaf){
			var context = this.model.get(this.handle, {raw: true}).getContext();
			if (context.is_fiel_attachment!==undefined && context.is_fiel_attachment==true){
				if (this.$buttons.find(".o_list_button_discard").length){
					var $import_button = $("<button type='button' class='btn btn-default btn-sm o_list_button_import_fiel_invoice_from_sat' accesskey='if'>Sync SAT CFDI</button>");
					this.$buttons.find(".o_list_button_discard").after($import_button);
					this.$buttons.on('click', '.o_list_button_import_fiel_invoice_from_sat', this._onImportFIELSatInvoice.bind(this));
				}
			}
		}
	},
	_onImportFIELSatInvoice: function (event) {
        event.stopPropagation();
        var self = this;
        self._rpc({
            model: 'res.company',
            method: 'import_current_company_invoice',
            args: [],
            
        }).then(function () {
            return;
        });
    },
    _onImportCfdiInvoice: function (event) {
        event.stopPropagation();
        return this.do_action({
            name: "Importar factura de compra",
            type: 'ir.actions.act_window',
            view_mode: 'form',
            views: [[false, 'form']],
            target: 'new',
            res_model: 'import.vendor.cfdi.xml.bill'
        });
        
    },
});

});