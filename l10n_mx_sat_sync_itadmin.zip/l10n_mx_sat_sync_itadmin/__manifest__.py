# -*- coding: utf-8 -*-

{
    'name':         'Synchronize CFDI files with SAT',
    'version': '    2.0',
    'description':  ''' 
                    Descarga los CFDI del portal del SAT a la base de datos de 
                    Odoo para su procesamiento y administracion
                    ''',
    'category':     'Accounting',
    'author':       'Nilesh Sheliya',
    'website':      '',
    'depends':      [
                    #'importar_xml_cfdi',
                    #'importar_facturas',
                    'account', 'cdfi_invoice','sale_purchase'
                    ],
    'data':         [
                    'security/ir.model.access.csv',
                    'security/l10n_mx_edi_esignature.xml',
                    'data/cron_data.xml',
                    
                    'views/ir_attachment_view.xml',
                    'views/res_config_settings_view.xml',
                    'views/templates.xml',
                    'views/res_company_view.xml',
                    'views/esignature_view.xml',
                    
                    'wizard/cfdi_invoice.xml',
                    'wizard/import_invoice_process_message.xml',
                    
                    ],
    'application':  False,
    'installable':  True,
    'license':      'OPL-1',    
}
